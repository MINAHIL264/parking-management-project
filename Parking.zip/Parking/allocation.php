<?php
// Database connection
include 'db.php';

// Get the SpaceID from the query string
$space_id = $_GET['space_id'] ?? null;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customer_name = $_POST['customer_name'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];

    // Fetch CustomerID
    $customer_query = "SELECT CustomerID FROM Customer WHERE Name = ?";
    $stmt = $conn->prepare($customer_query);
    $stmt->bind_param("s", $customer_name);
    $stmt->execute();
    $customer_result = $stmt->get_result();
    $customer = $customer_result->fetch_assoc();
    $customer_id = $customer['CustomerID'] ?? null;

    // Fetch VehicleID
    $vehicle_query = "SELECT VehicleID FROM Vehicle WHERE OwnerID = ?";
    $stmt = $conn->prepare($vehicle_query);
    $stmt->bind_param("i", $customer_id);
    $stmt->execute();
    $vehicle_result = $stmt->get_result();
    $vehicle = $vehicle_result->fetch_assoc();
    $vehicle_id = $vehicle['VehicleID'] ?? null;

    // Insert allocation into the database
    if ($customer_id && $vehicle_id) {
        $allocation_query = "INSERT INTO Allocation (SpaceID, VehicleID, StartTime, EndTime) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($allocation_query);
        $stmt->bind_param("iiss", $space_id, $vehicle_id, $start_time, $end_time);
        if ($stmt->execute()) {
            header("Location: payment.php?space_id=$space_id&vehicle_id=$vehicle_id");
            exit;
        } else {
            $error = "Failed to allocate the parking space. Please try again.";
        }
    } else {
        $error = "Customer or vehicle not found. Please ensure the details are correct.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Allocate Parking Space</title>
    <link rel="stylesheet" href="allocation.css">
    <link rel="stylesheet" href="index.css">

</head>
<body>
    <!-- Header Section -->
    <header class="header">
        <div class="container">
            <h1 class="logo">ParkingPro</h1>
            <nav class="nav">
                <a href="index.php">Home</a>
                <a href="registration.php">Register</a>
                <a href="view_parking.php">View Parking</a>
                <a href="contact.php">Contact</a>
            </nav>
        </div>
    </header>

    <!-- Allocation Form -->
    <section class="allocation-section">
        <div class="container">
            <h2>Allocate Parking Space</h2>
            <?php if (!empty($error)): ?>
                <div class="error"><?= $error ?></div>
            <?php endif; ?>
            <form method="POST" class="form">
                <div class="form-group">
                    <label for="customer_name">Customer Name:</label>
                    <input type="text" id="customer_name" name="customer_name" required>
                </div>
                <div class="form-group">
                    <label for="start_time">Start Time:</label>
                    <input type="datetime-local" id="start_time" name="start_time" required>
                </div>
                <div class="form-group">
                    <label for="end_time">End Time:</label>
                    <input type="datetime-local" id="end_time" name="end_time" required>
                </div>
                <button type="submit" class="button">Allocate</button>
            </form>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="footer">
        <p>© 2025 ParkingPro. All Rights Reserved.</p>
        <p>Follow us on 
            <a href="#">Facebook</a>, 
            <a href="#">Twitter</a>, 
            <a href="#">Instagram</a>
        </p>
    </footer>
</body>
</html>
