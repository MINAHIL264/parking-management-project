<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Debug: Print the entire $_POST array
    echo '<pre>';
    print_r($_POST);
    echo '</pre>';

    $name = $_POST['customer_name']; 
    $phoneNumber = $_POST['phone_number']; 
    $email = $_POST['email']; 
    $address = $_POST['address']; 
    $licensePlate = $_POST['license']; 
    $make = $_POST['make']; 
    $model = $_POST['model']; 

    // Database operations
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sqlCustomer = "INSERT INTO Customer (Name, PhoneNumber, Email, Address) 
                    VALUES ('$name', '$phoneNumber', '$email', '$address')";
    if ($conn->query($sqlCustomer) === TRUE) {
        $customerId = $conn->insert_id;

        $sqlVehicle = "INSERT INTO Vehicle (LicensePlate, Make, Model, OwnerID) 
                       VALUES ('$licensePlate', '$make', '$model', '$customerId')";
        if ($conn->query($sqlVehicle) === TRUE) {
            echo "Registration successful!";
            header("Location: index.php");

        } else {
            echo "Error inserting vehicle data: " . $sqlVehicle . "<br>" . $conn->error;
        }
    } else {
        echo "Error inserting customer data: " . $sqlCustomer . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
