<?php
// Database connection
include 'db.php';

// Get SpaceID and VehicleID from the query string
$space_id = $_GET['space_id'] ?? null;
$vehicle_id = $_GET['vehicle_id'] ?? null;

// Fetch relevant parking space and allocation details
if ($space_id && $vehicle_id) {
    // Fetch space rate
    $space_query = "SELECT RatePerHour FROM ParkingSpace WHERE SpaceID = ?";
    $stmt = $conn->prepare($space_query);
    $stmt->bind_param("i", $space_id);
    $stmt->execute();
    $space_result = $stmt->get_result();
    $space = $space_result->fetch_assoc();
    $rate_per_hour = $space['RatePerHour'] ?? 0;

    // Fetch allocation duration
    $allocation_query = "SELECT StartTime, EndTime FROM Allocation WHERE SpaceID = ? AND VehicleID = ?";
    $stmt = $conn->prepare($allocation_query);
    $stmt->bind_param("ii", $space_id, $vehicle_id);
    $stmt->execute();
    $allocation_result = $stmt->get_result();
    $allocation = $allocation_result->fetch_assoc();

    if ($allocation) {
        $start_time = new DateTime($allocation['StartTime']);
        $end_time = new DateTime($allocation['EndTime']);
        $interval = $start_time->diff($end_time);
        $hours = $interval->h + ($interval->days * 24); // Convert days to hours
        $amount = $hours * $rate_per_hour; // Calculate total amount
    } else {
        $error = "Allocation details not found.";
    }
} else {
    $error = "Invalid space or vehicle information.";
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $payment_method = $_POST['payment_method'];

    // Insert payment details into the database
    $payment_query = "INSERT INTO Payment (VehicleID, Amount, Date, Method) VALUES (?, ?, NOW(), ?)";
    $stmt = $conn->prepare($payment_query);
    $stmt->bind_param("ids", $vehicle_id, $amount, $payment_method);

    if ($stmt->execute()) {
        $success = "Payment successfully processed.";
    } else {
        $error = "Failed to process payment. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <link rel="stylesheet" href="payment.css">
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <!-- Header Section -->
    <header class="header">
        <div class="container">
            <h1 class="logo">ParkingPro</h1>
            <nav class="nav">
                <a href="index.php">Home</a>
                <a href="registration.php">Register</a>
                <a href="view_parking.php">View Parking</a>
                <a href="contact.php">Contact</a>
            </nav>
        </div>
    </header>

    <!-- Payment Section -->
    <section class="payment-section">
        <div class="container">
            <h2>Payment</h2>
            <?php if (!empty($error)): ?>
                <div class="error"><?= $error ?></div>
            <?php elseif (!empty($success)): ?>
                <div class="success"><?= $success ?></div>
            <?php else: ?>
                <p>Space Rate: $<?= number_format($rate_per_hour, 2) ?> per hour</p>
                <p>Duration: <?= $hours ?> hours</p>
                <p>Total Amount: $<?= number_format($amount, 2) ?></p>
                <form method="POST" class="form">
                    <div class="form-group">
                        <label for="payment_method">Payment Method:</label>
                        <select id="payment_method" name="payment_method" required>
                            <option value="Credit Card">Credit Card</option>
                            <option value="Debit Card">Debit Card</option>
                            <option value="PayPal">PayPal</option>
                            <option value="Cash">Cash</option>
                        </select>
                    </div>
                    <button type="submit" class="button">Pay Now</button>
                </form>
            <?php endif; ?>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="footer">
        <p>© 2025 ParkingPro. All Rights Reserved.</p>
        <p>Follow us on 
            <a href="#">Facebook</a>, 
            <a href="#">Twitter</a>, 
            <a href="#">Instagram</a>
        </p>
    </footer>
</body>
</html>
