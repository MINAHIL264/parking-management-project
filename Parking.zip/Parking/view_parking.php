<?php
// Database connection
include 'db.php';

// Fetch available parking spaces
$query = "SELECT * FROM ParkingSpace WHERE Status = 'Available'";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Parking Spaces</title>
    <link rel="stylesheet" href="parking.css">
    <link rel="stylesheet" href="index.css">

</head>
<body>
    <!-- Header Section -->
    <header class="header">
        <div class="container">
            <h1 class="logo">ParkingPro</h1>
            <nav class="nav">
                <a href="index.php">Home</a>
                <a href="registration.php">Register</a>
                <a href="view_parking.php">View Parking</a>
                <a href="contact.php">Contact</a>
            </nav>
        </div>
    </header>

    <!-- Main Content -->
    <section class="parking-section">
        <div class="container">
            <h2>Available Parking Spaces</h2>
            <table class="parking-table">
                <thead>
                    <tr>
                        <th>Space ID</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Size</th>
                        <th>Rate/Hour</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($result) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?= $row['SpaceID'] ?></td>
                                <td><?= $row['Location'] ?></td>
                                <td><?= $row['Status'] ?></td>
                                <td><?= $row['Size'] ?></td>
                                <td>$<?= number_format($row['RatePerHour'], 2) ?></td>
                                <td>
                                    <a href="allocation.php?space_id=<?= $row['SpaceID'] ?>" class="button">Get Allocation</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6">No available parking spaces at the moment.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="footer">
        <p>© 2025 ParkingPro. All Rights Reserved.</p>
        <p>Follow us on 
            <a href="#">Facebook</a>, 
            <a href="#">Twitter</a>, 
            <a href="#">Instagram</a>
        </p>
    </footer>
</body>
</html>
