<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Page</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="registration.css">

</head>
<body>
    <div class="container">
        <h1>Registration</h1>
        <form action="register_process.php" method="POST">
            <!-- Customer Details -->
            <div class="form-group">
                <label for="name">Customer Name</label>
                <input type="text" id="name" name="customer_name" placeholder="Enter your full name" required>
            </div>

            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="text" id="phone" name="phone_number" placeholder="Enter your phone number" required>
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="Enter your email address" required>
            </div>

            <div class="form-group">
                <label for="address">Address</label>
                <input type="text" id="address" name="address" placeholder="Enter your address" required>
            </div>

            <!-- Vehicle Details -->
            <div class="form-group">
                <label for="license">License Plate</label>
                <input type="text" id="license_plate" name="license" placeholder="Enter your vehicle license plate" required>
            </div>

            <div class="form-group">
                <label for="make">Vehicle Make</label>
                <input type="text" id="make" name="make" placeholder="Enter vehicle make (e.g., Toyota)" required>
            </div>

            <div class="form-group">
                <label for="model">Vehicle Model</label>
                <input type="text" id="model" name="model" placeholder="Enter vehicle model (e.g., Corolla)" required>
            </div>

            <button type="submit" class="btn">Register</button>
        </form>
    </div>
</body>
</html>