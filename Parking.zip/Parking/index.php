<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking Management System</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <!-- Header Section -->
    <header class="header">
        <div class="container">
            <h1 class="logo">ParkingPro</h1>
            <nav class="nav">
                <a href="index.php">Home</a>
                <a href="registration.php">Register</a>
                <a href="view_parking.php">View Parking</a>
                <a href="contact.php">Contact</a>
            </nav>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
            <h1>Welcome to ParkingPro</h1>
            <p>Effortlessly manage your parking needs with our smart system.</p>
            <a href="view_parking.php" class="cta-button">Get Started</a>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features">
        <h2>Our Features</h2>
        <div class="feature-list">
            <div class="feature">
                <i class="icon">🚗</i>
                <h3>Easy Allocation</h3>
                <p>Reserve a spot in just a few clicks.</p>
            </div>
            <div class="feature">
                <i class="icon">💳</i>
                <h3>Secure Payments</h3>
                <p>Pay seamlessly with multiple payment options.</p>
            </div>
            <div class="feature">
                <i class="icon">📊</i>
                <h3>Real-Time Updates</h3>
                <p>Stay updated with live parking availability.</p>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="footer">
        <p>© 2025 ParkingPro. All Rights Reserved.</p>
        <p>Follow us on 
            <a href="#">Facebook</a>, 
            <a href="#">Twitter</a>, 
            <a href="#">Instagram</a>
        </p>
    </footer>
</body>
</html>
