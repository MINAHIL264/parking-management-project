<?php
include 'db.php'; // Assuming db.php contains database connection details

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $location = $_POST['location'];
    $size = $_POST['size'];
    $ratePerHour = $_POST['rate_per_hour'];

    // Database connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert new parking space
    $sql = "INSERT INTO ParkingSpace (Location, Size, RatePerHour, Status) 
            VALUES ('$location', '$size', '$ratePerHour', 'Available')";

    if ($conn->query($sql) === TRUE) {
        echo "<div class='success'>Parking space added successfully!</div>";
    } else {
        echo "<div class='error'>Error adding parking space: " . $conn->error . "</div>";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Parking Space</title>
    <link rel="stylesheet" href="style.css"> 
    <link rel="stylesheet" href="index.css">
</head>
<body>

<div class="admin-section">
    <h2>Add New Parking Space</h2>
    <form action="add_parking.php" method="POST">
        <div class="form-group">
            <label for="location">Location</label>
            <input type="text" id="location" name="location" placeholder="Enter location" required>
        </div>

        <div class="form-group">
            <label for="size">Size</label>
            <input type="text" id="size" name="size" placeholder="Enter size (e.g., Small, Medium, Large)" required>
        </div>

        <div class="form-group">
            <label for="rate_per_hour">Rate Per Hour</label>
            <input type="number" id="rate_per_hour" name="rate_per_hour" step="0.01" placeholder="Enter rate per hour" required>
        </div>

        <button type="submit" class="btn-submit">Add Parking Space</button>
    </form>
</div>

</body>

</html>
